from inspect import _void
import jwt
from passlib.context import CryptContext
from uuid import UUID
from sqlmodel import select
from datetime import datetime, timedelta, timezone

from core import settings, SessionDep
from core.schema import ResponseMessage
from core.db import get_db
from .schema import User, UserClaims
from .exception import (
    InvalidTokenException,
    TokenExpiredException,
    ChangePasswordException,
)


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


async def verify_user(username: str, password: str, session: SessionDep) -> User | None:
    statement = select(User).where(User.username == username)
    result = await session.execute(statement)
    user = result.scalar_one_or_none()

    if not user:
        return None
    if not verify_password(password, user.password):
        return None
    return user


def verify_password(password: str, hashed_password: str) -> bool:
    return pwd_context.verify(password + settings.SECRET, hashed_password)


def hash_password(password: str) -> str:
    salted_password = password + settings.SECRET
    return pwd_context.hash(salted_password)


async def update_password(
    session: SessionDep, user_id: UUID, old_password: str, new_password: str
):
    item = await session.get(User, user_id)
    if not item:
        raise ChangePasswordException(detail="user not found.")

    if not verify_password(old_password, item.password):
        raise ChangePasswordException(detail="old password not correct.")
    item.password = hash_password(new_password)
    await session.commit()


def create_token(user: User, token_type: str, expries_delta_min: int) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=expries_delta_min)
    to_encode = {
        "user_id": str(user.id),
        "username": user.username,
        "root": user.root,
        "exp": expire,
        "iat": datetime.now(timezone.utc),
        "type": token_type,
    }
    encoded_jwt = jwt.encode(
        to_encode, settings.SECRET, algorithm=settings.AUTH_ALGORITHM
    )
    return encoded_jwt


def verify_token(token: str, token_type: str) -> UserClaims:
    try:
        payload = jwt.decode(
            token, settings.SECRET, algorithms=[settings.AUTH_ALGORITHM]
        )
        user_id: str | None = payload.get("user_id")
        username: str | None = payload.get("username")
        token_type_in_payload: str | None = payload.get("type")

        if (
            user_id is None
            or username is None
            or token_type_in_payload is None
            or token_type_in_payload != token_type
        ):
            raise InvalidTokenException()

        return UserClaims(
            user_id=UUID(user_id),
            username=username,
            root=payload.get("root", False),
            exp=payload.get("exp"),
            iat=payload.get("iat"),
            type=token_type_in_payload,
        )
    except jwt.ExpiredSignatureError:
        raise TokenExpiredException()
    except jwt.PyJWTError:
        raise InvalidTokenException()


async def create_root_user() -> None:
    db_gen = get_db()
    session = await db_gen.__anext__()
    try:
        statement = select(User).where(User.root == True)
        result = await session.execute(statement)
        root_user = result.scalar_one_or_none()

        if root_user is None:
            root_user = User(
                username="root",
                password=hash_password("123456"),
                name="Root",
                email="root@example.com",
                root=True,
            )
            session.add(root_user)
            await session.commit()
            print(
                "Root user created successfully with username: root, password: 123456"
            )
    finally:
        await db_gen.aclose()
