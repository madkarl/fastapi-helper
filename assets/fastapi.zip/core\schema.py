from pydantic import BaseModel
from typing import List, TypeVar, Generic


class Message(BaseModel):
    message: str


T = TypeVar("T")


class Pagination(BaseModel, Generic[T]):
    items: List[T]
    total: int
    page: int
    size: int
