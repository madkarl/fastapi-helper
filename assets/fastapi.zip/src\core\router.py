from fastapi import FastAPI


def setup_router(app: FastAPI):
    pass
