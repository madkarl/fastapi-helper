from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from fastapi import Depends
from typing import Annotated

from .settings import settings


engine = create_async_engine(settings.SQLALCHEMY_DATABASE_URI, echo=settings.DEBUG)


async def get_db() -> AsyncSession:
    async with sessionmaker(engine, class_=AsyncSession)() as session:
        yield session


SessionDep = Annotated[AsyncSession, Depends(get_db)]
