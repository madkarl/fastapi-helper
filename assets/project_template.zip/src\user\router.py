from uuid import UUID
from fastapi import APIRouter, Depends

from core import Service, SessionDep, Pagination, ResponseMessage
from .schema import UserCreate, UserUpdate, UserRead, User
from .auth_router import router as auth_router
from .constant import USER_URI
from .dependency import get_root_info, GetUserInfoDep
from .tool import hash_password, update_password
from .exception import PrivilegesException

router = APIRouter(prefix=USER_URI, tags=["user"])
router.include_router(auth_router)


@router.post("/", dependencies=[Depends(get_root_info)])
async def create_user(session: SessionDep, user_in: UserCreate) -> UserRead:
    # 对密码进行哈希处理
    user_data = user_in.model_dump()
    user_data["password"] = hash_password(user_in.password)
    user_create = UserCreate.model_validate(user_data)

    service = Service[UserCreate, UserRead, UserUpdate](session, User)
    user = await service.create(user_create)
    return user


@router.get("/profile")
async def get_user_profile(session: SessionDep, user: GetUserInfoDep) -> UserRead:
    service = Service[UserCreate, UserRead, UserUpdate](session, User)
    user = await service.get(user.user_id)
    return user


@router.get("/{user_id}", dependencies=[Depends(get_root_info)])
async def get_user(session: SessionDep, user_id: UUID) -> UserRead:
    service = Service[UserCreate, UserRead, UserUpdate](session, User)
    user = await service.get(user_id)
    return user


@router.get("/", dependencies=[Depends(get_root_info)])
async def list_users(
    session: SessionDep, page_index: int = 1, page_size: int = 20
) -> Pagination[UserRead]:
    service = Service[UserCreate, UserRead, UserUpdate](session, User)
    users = await service.list(page_index, page_size)
    return users


@router.put("/{user_id}", dependencies=[Depends(get_root_info)])
async def update_user(
    session: SessionDep, user_id: UUID, user_in: UserPartialUpdate
) -> UserRead:
    # 只获取实际提供的字段（排除None值）
    user_data = user_in.model_dump(exclude_unset=True, exclude_none=True)
    
    # 如果更新密码，需要进行哈希处理
    if "password" in user_data and user_data["password"] is not None:
        user_data["password"] = hash_password(user_data["password"])
    
    # 创建UserUpdate实例用于数据库操作
    user_update = UserUpdate.model_validate(user_data)

    service = Service[UserCreate, UserRead, UserUpdate](session, User)
    user = await service.update(user_id, user_update)
    return user


@router.delete("/{user_id}", dependencies=[Depends(get_root_info)])
async def delete_user(session: SessionDep, user_id: UUID) -> ResponseMessage:
    service = Service[UserCreate, UserRead, UserUpdate](session, User)
    return await service.delete(user_id)


@router.post("/{user_id}/password")
async def update_user_password(
    session: SessionDep,
    user: GetUserInfoDep,
    user_id: UUID,
    old_pssword: str,
    new_password: str,
) -> ResponseMessage:
    if user.user_id != user_id and user.root == False:
        raise PrivilegesException()
    await update_password(session, user_id, old_pssword, new_password)
    return ResponseMessage("password updated.")
