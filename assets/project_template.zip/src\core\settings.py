from pydantic_settings import BaseSettings
from pydantic_core import MultiHostUrl
from pydantic import computed_field


class Settings(BaseSettings):
    # App Settings
    PROJECT_NAME: str = "${project_name}"
    DESCRIPTION: str = "${description}"
    API_PREFIX: str = "/api/v1"
    DEBUG: bool = False
    VERSION: str = "0.1.0"
    DOC_URL: str | None = "/docs"
    REDOC_URL: str | None = "/redoc"

    SECRET: str = "${secret}"
    ACCESS_TOKEN_EXPIRE_MIN: int = 30
    REFRESH_TOKEN_EXPIRE_MIN: int = 60 * 24 * 7
    AUTH_ALGORITHM: str = "HS256"

    # Allow CORS
    CORS_ALLOW_ORIGINS: list = ["*"]
    CORS_ALLOW_CREDENTIALS: bool = True
    CORS_ALLOW_METHODS: list = ["*"]
    CORS_ALLOW_HEADERS: list = ["*"]

    # GZIP Settings
    GZIP_MINIMUM_SIZE: int = 2000
    GZIP_COMPRESS_LEVEL: int = 9

    # Database Settings
    DB_HOST: str = "${db_host}"
    DB_PORT: str = "${db_port}"
    DB_USERNAME: str = "${db_username}"
    DB_PASSWORD: str = "${db_password}"
    DB_NAME: str = "${db_name}"

    @computed_field
    @property
    def SQLALCHEMY_DATABASE_URI(self) -> MultiHostUrl:
        return MultiHostUrl.build(
            scheme="postgresql+asyncpg",
            username=self.DB_USERNAME,
            password=self.DB_PASSWORD,
            host=self.DB_HOST,
            port=int(self.DB_PORT),
            path=self.DB_NAME,
        )


settings = Settings()
