from fastapi import APIRouter, Depends
from fastapi.security import OAuth2PasswordRequestForm
from typing import Annotated
from core import Service, SessionDep, settings

from .schema import UserCreate, UserUpdate, UserRead, User
from .tool import verify_user, create_token, verify_token
from .exception import AuthException
from .schema import (
    LoginRequest,
    RefreshRequest,
    AuthToken,
)
from .constant import AUTH_URI, SWAGGER_URI


router = APIRouter(prefix=AUTH_URI)


@router.post(SWAGGER_URI, response_model=AuthToken)
async def login_swagger(
    session: SessionDep, form_data: Annotated[OAuth2PasswordRequestForm, Depends()]
) -> AuthToken:
    user = await verify_user(form_data.username, form_data.password, session)
    if not user:
        raise AuthException(detail="用户名或密码不正确")

    access_token = create_token(user, "access", settings.ACCESS_TOKEN_EXPIRE_MIN)
    refresh_token = create_token(user, "refresh", settings.REFRESH_TOKEN_EXPIRE_MIN)
    return AuthToken(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MIN * 60,
    )


@router.post("/login", response_model=AuthToken)
async def login(session: SessionDep, login_data: LoginRequest) -> AuthToken:
    user = await verify_user(login_data.username, login_data.password, session)
    if not user:
        raise AuthException(detail="username or password is incorrect.")

    access_token = create_token(user, "access", settings.ACCESS_TOKEN_EXPIRE_MIN)
    refresh_token = create_token(user, "refresh", settings.REFRESH_TOKEN_EXPIRE_MIN)
    return AuthToken(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MIN * 60,
    )


@router.post("/refresh", response_model=AuthToken)
async def refresh_token(session: SessionDep, refresh_data: RefreshRequest) -> AuthToken:
    claims = verify_token(refresh_data.refresh_token, "refresh")

    service = Service[UserCreate, UserRead, UserUpdate](session, User)
    user = await service.get(claims.user_id)
    if not user:
        raise AuthException(detail="user not found.")

    access_token = create_token(user, "access", settings.ACCESS_TOKEN_EXPIRE_MIN)
    refresh_token = create_token(user, "refresh", settings.REFRESH_TOKEN_EXPIRE_MIN)
    return AuthToken(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MIN * 60,
    )
