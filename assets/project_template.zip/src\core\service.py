from sqlmodel import SQLModel, select, func
from fastapi import HTTPException, status
from .schema import ResponseMessage, Pagination
from .dependency import SessionDep


class Service[TCreate, TRead, TUpdate]:
    def __init__(self, session: SessionDep, schema: SQLModel):
        self.session = session
        self.schema = schema

    async def create(self, item: TCreate) -> TRead:
        item = self.schema.model_validate(item)  # type: ignore
        self.session.add(item)
        await self.session.commit()
        await self.session.refresh(item)
        return item  # type: ignore

    async def get(self, item_id) -> TRead:
        item = await self.session.get(self.schema, item_id)  # type: ignore
        if not item:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Item not found"
            )
        return item

    async def list(
        self, page_index: int | None = None, page_size: int | None = None
    ) -> Pagination[TRead]:
        count_statement = select(func.count()).select_from(self.schema)  # type: ignore
        result = await self.session.execute(count_statement)
        count = result.one()[0]

        select_statement = select(self.schema)  # type: ignore
        if page_index or page_size:
            if not page_size:
                page_size = 20
            if not page_index:
                page_index = 1
            offset = (page_index - 1) * page_size
            select_statement = select_statement.offset(offset).limit(page_size)
        result = await self.session.execute(select_statement)
        items = result.all()
        items = [item[0] for item in items]
        return Pagination[TRead](
            items=items, total=count, page=page_index, size=len(items)  # type: ignore
        )

    async def list_all(self) -> Pagination[TRead]:
        select_statement = select(self.schema)  # type: ignore
        result = await self.session.execute(select_statement)
        items = result.all()
        items = [item[0] for item in items]
        return Pagination(total=len(items), size=len(items), items=items)  # type: ignore

    async def update(self, item_id: int, item_in: TUpdate) -> TRead:
        item = await self.session.get(self.schema, item_id)  # type: ignore
        if not item:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Item not found"
            )
        item_data = item_in.model_dump(exclude_unset=True)  # type: ignore
        for field, value in item_data.items():
            setattr(item, field, value)
        await self.session.commit()
        await self.session.refresh(item)
        return item

    async def delete(self, item_id) -> ResponseMessage:
        item = await self.session.get(self.schema, item_id)  # type: ignore
        if not item:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Item not found"
            )
        await self.session.delete(item)
        await self.session.commit()
        return ResponseMessage(msg="Item deleted")
