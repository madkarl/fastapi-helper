USER_URI = "/user"
AUTH_URI = "/auth"
SWAGGER_URI = "/swagger_login"
