from fastapi import Depends
from fastapi.security import OAuth2PasswordBearer
from typing import Annotated

from core import settings
from .tool import verify_token
from .schema import UserClaims
from .exception import (
    AuthException,
    InvalidTokenException,
    TokenExpiredException,
    PrivilegesException,
)
from .constant import USER_URI, AUTH_URI, SWAGGER_URI

security = OAuth2PasswordBearer(
    tokenUrl=f"{settings.API_PREFIX}{USER_URI}{AUTH_URI}{SWAGGER_URI}"
)


def get_user_info(
    token: Annotated[str, Depends(security)],
) -> UserClaims:
    """
    获取当前登录用户信息
    验证JWT token的有效性和是否过期
    """
    try:
        user_claims = verify_token(token, "access")
        return user_claims
    except (InvalidTokenException, TokenExpiredException) as e:
        raise e
    except Exception:
        raise AuthException("Authentication failed")


def get_root_info(
    current_user: Annotated[UserClaims, Depends(get_user_info)],
) -> UserClaims:
    """
    获取当前管理员用户信息
    验证用户是否为管理员权限
    """
    if not current_user.root:
        raise PrivilegesException()
    return current_user


GetUserInfoDep = Annotated[UserClaims, Depends(get_user_info)]
GetRootInfoDep = Annotated[UserClaims, Depends(get_root_info)]
