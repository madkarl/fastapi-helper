from fastapi import FastAPI
from contextlib import asynccontextmanager

from core import logger, setup_logger, settings, setup_middleware, setup_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Application startup...")
    yield
    # Shutdown
    logger.info("Application shutdown...")


setup_logger()

app = FastAPI(
    title=settings.PROJECT_NAME,
    description=settings.DESCRIPTION,
    debug=settings.DEBUG,
    version=settings.VERSION,
    docs_url=settings.DOC_URL,
    redoc_url=settings.REDOC_URL,
    lifespan=lifespan,
)

setup_middleware(app)
setup_router(app)
