from fastapi import FastAPI
from contextlib import asynccontextmanager

from core import settings, setup_middleware, setup_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    print("Startup")
    yield
    # Shutdown
    print("Shutdown")


app = FastAPI(
    title=settings.PROJECT_NAME,
    description=settings.DESCRIPTION,
    debug=settings.DEBUG,
    version=settings.VERSION,
    docs_url=settings.DOC_URL,
    redoc_url=settings.REDOC_URL,
    lifespan=lifespan,
)


setup_middleware(app)
setup_router(app)
