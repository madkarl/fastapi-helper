import os
import sys
import ast
import subprocess
from pathlib import Path


def find_sqlmodel_classes(src_dir: str) -> list[str]:
    """遍历src目录，找到所有SQLModel的table类并生成import语句"""
    import_statements = []
    src_path = Path(src_dir)

    # 遍历src目录下的所有子目录
    for item in src_path.iterdir():
        if item.is_dir() and item.name != "core" and item.name != "__pycache__":
            schema_file = item / "schema.py"
            if schema_file.exists():
                table_classes = parse_schema_file(schema_file, item.name)
                import_statements.extend(table_classes)

    return import_statements


def parse_schema_file(schema_file: Path, module_name: str) -> list[str]:
    """解析schema.py文件，找到table=True的SQLModel类"""
    import_statements = []

    try:
        with open(schema_file, "r", encoding="utf-8") as f:
            content = f.read()

        # 解析AST
        tree = ast.parse(content)

        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                # 检查是否有table=True参数
                if has_table_true(node):
                    import_statements.append(
                        f"from src.{module_name}.schema import {node.name}"
                    )

    except Exception as e:
        print(f"Error parsing {schema_file}: {e}")

    return import_statements


def has_table_true(class_node: ast.ClassDef) -> bool:
    """检查类定义是否包含table=True参数"""
    for base in class_node.bases:
        # 检查基类调用中是否有table=True
        if isinstance(base, ast.Call):
            for keyword in base.keywords:
                if keyword.arg == "table" and isinstance(keyword.value, ast.Constant):
                    if keyword.value.value is True:
                        return True

    # 检查类定义的关键字参数
    if hasattr(class_node, "keywords"):
        for keyword in class_node.keywords:
            if keyword.arg == "table" and isinstance(keyword.value, ast.Constant):
                if keyword.value.value is True:
                    return True

    return False


def update_alembic_env(import_statements: list[str]) -> bool:
    """将import_statements写入到alembic/env.py文件中"""
    try:
        # 获取alembic/env.py文件路径
        src_dir = os.path.dirname(os.path.abspath(__file__))
        project_dir = os.path.dirname(src_dir)
        env_py_path = os.path.join(project_dir, "alembic", "env.py")

        # 读取env.py文件内容
        with open(env_py_path, "r", encoding="utf-8") as f:
            content = f.read()

        # 定位标记位置
        start_marker = "### auto generate start ###"
        end_marker = "### auto generate end ###"

        start_pos = content.find(start_marker)
        end_pos = content.find(end_marker)

        if start_pos == -1 or end_pos == -1:
            print(f"Error: Markers not found in {env_py_path}")
            return False

        # 构建新内容
        start_part = content[: start_pos + len(start_marker) + 1]  # +1 for newline
        end_part = content[end_pos:]

        # 生成import语句部分
        imports_part = (
            "\n".join(import_statements) + "\n" if import_statements else "\n"
        )

        # 组合新内容
        new_content = start_part + imports_part + end_part

        # 写入文件
        with open(env_py_path, "w", encoding="utf-8") as f:
            f.write(new_content)

        print(f"Updated {env_py_path} with {len(import_statements)} import statements")
        return True

    except Exception as e:
        print(f"Error updating alembic env.py: {e}")
        return False


def execute_alembic_commands(message: str) -> bool:
    """执行alembic命令"""
    try:
        # 执行alembic revision命令
        revision_cmd = f'alembic revision --autogenerate -m "{message}"'
        print(f"Executing: {revision_cmd}")

        result = subprocess.run(
            revision_cmd, shell=True, capture_output=True, text=True
        )
        if result.returncode != 0:
            print(f"Error in revision: {result.stderr}")
            return False

        print(result.stdout)

        # 执行alembic upgrade命令
        upgrade_cmd = "alembic upgrade head"
        print(f"Executing: {upgrade_cmd}")

        result = subprocess.run(upgrade_cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"Error in upgrade: {result.stderr}")
            return False

        print(result.stdout)
        return True

    except Exception as e:
        print(f"Error executing alembic commands: {e}")
        return False


def migrate():
    """主迁移函数"""
    # 1. 获取命令行参数
    if len(sys.argv) < 2:
        print("Usage: python migrate.py <migration_message>")
        print("Example: python migrate.py 'add user table'")
        sys.exit(1)

    message = sys.argv[1]

    # 2. 找到所有SQLModel类并生成import语句
    src_dir = os.path.dirname(os.path.abspath(__file__))
    import_statements = find_sqlmodel_classes(src_dir)

    if import_statements:
        print("Found SQLModel table classes:")
        for stmt in import_statements:
            print(f"  {stmt}")
    else:
        print("No SQLModel table classes found")

    # 3. 更新alembic/env.py文件
    if not update_alembic_env(import_statements):
        print("Failed to update alembic/env.py")
        sys.exit(1)

    # 4. 执行alembic命令
    success = execute_alembic_commands(message)

    # 5. 打印结果
    if success:
        print("migrate success")
    else:
        print("migrate failed")
        sys.exit(1)


if __name__ == "__main__":
    migrate()
