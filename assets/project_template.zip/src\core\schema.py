from pydantic import BaseModel
from typing import List, TypeVar, Generic


class ResponseMessage(BaseModel):
    msg: str


T = TypeVar("T")


class Pagination(BaseModel, Generic[T]):
    items: List[T]
    total: int
    page: int
    size: int
