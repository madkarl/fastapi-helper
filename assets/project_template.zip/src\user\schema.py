from typing import Optional
from uuid import UUID, uuid4
from sqlmodel import Field, SQLModel
from pydantic import BaseModel


class UserBase(SQLModel):
    username: str = Field(max_length=255, unique=True)
    email: Optional[str] = Field(max_length=255, default=None)
    name: str = Field(max_length=255)
    root: bool = Field(default=False)


class UserCreate(UserBase):
    password: str = Field(max_length=255)


class UserRead(UserBase):
    id: UUID


class UserUpdate(UserBase):
    pass


class User(UserBase, table=True):
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    password: str = Field(max_length=255)


class AuthToken(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class TokenData(BaseModel):
    user_id: Optional[UUID] = None
    username: Optional[str] = None


class LoginRequest(BaseModel):
    username: str
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


class UserClaims(BaseModel):
    user_id: UUID
    username: str
    root: bool = False
    exp: int
    iat: int
    type: str  # "access" or "refresh"
