import logging

logger = logging.getLogger("uvicorn")


def setup_logger():
    pass
