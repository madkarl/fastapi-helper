import asyncio
from user.tool import create_root_user


async def initialize_data():
    await create_root_user()


if __name__ == "__main__":
    asyncio.run(initialize_data())
