import importlib
from pathlib import Path
from fastapi import FastAPI, APIRouter

from .logger import logger
from .settings import settings


def setup_router(app: FastAPI):
    """自动加载src目录下所有模块中的APIRouter对象"""
    # 获取src目录的路径
    src_dir = Path(__file__).parent.parent

    # 遍历src目录下的所有子目录
    for module_dir in src_dir.iterdir():
        if module_dir.is_dir() and module_dir.name != "__pycache__":
            # 检查是否存在router.py文件
            router_file = module_dir / "router.py"
            if router_file.exists():
                module_name = f"{module_dir.name}.router"
                try:
                    router_module = importlib.import_module(module_name)

                    if hasattr(router_module, "router"):
                        router_obj = getattr(router_module, "router")
                        if isinstance(router_obj, APIRouter):
                            app.include_router(
                                router=router_obj,
                                prefix=settings.API_PREFIX,
                            )
                            logger.info(f"Auto import router from: {module_name}")
                except ImportError as e:
                    logger.error(f"Import router from {module_name} failed: {e}")
                except Exception as e:
                    logger.error(f"Load router from {module_name} failed: {e}")
