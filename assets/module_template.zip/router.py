from fastapi import APIRouter


router = APIRouter(prefix=f"/${router_name}", tags=[f"${router_name}"])
