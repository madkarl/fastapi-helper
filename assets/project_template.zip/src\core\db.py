from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from .settings import settings


engine = create_async_engine(str(settings.SQLALCHEMY_DATABASE_URI), echo=settings.DEBUG)


async def get_db() -> AsyncSession:
    async with sessionmaker(engine, class_=AsyncSession)() as session:
        yield session
